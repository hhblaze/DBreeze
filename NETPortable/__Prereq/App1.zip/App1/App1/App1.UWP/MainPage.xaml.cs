﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

using DBreeze;
using DBreeze.Programmers;
using System.Threading.Tasks;

namespace App1.UWP
{
    public sealed partial class MainPage
    {
        public App1.App PortableApp = null;

        public MainPage()
        {
            this.InitializeComponent();          

            if (PortableApp == null)
            {
                PortableApp = new App1.App();

                FSFactory fsf = new FSFactory();

                Windows.Storage.StorageFolder localFolder = Windows.Storage.ApplicationData.Current.LocalFolder;

                PortableApp.engine = new DBreezeEngine(new DBreezeConfiguration()
                {
                    DBreezeDataFolderName = localFolder.Path,
                    FSFactory = fsf
                });
            }

            LoadApplication(this.PortableApp);


        }
    }
}
