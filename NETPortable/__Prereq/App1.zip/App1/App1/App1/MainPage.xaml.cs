﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;


namespace App1
{
    public partial class MainPage : ContentPage
    {
        
        public MainPage()
        {
            InitializeComponent();
            
        }


        void OnButtonClicked(object sender, EventArgs args)
        {
            using (var tran = App.MAIN.engine.GetTransaction())
            {
                tran.Insert<int, int>("jdsf", 1, 1);
                tran.Commit();
            }
                //this.Dialogs.Toast(new ToastConfig(@event, @event.ToString(), "Testing toast functionality....fun!")
                //{
                //    Duration = TimeSpan.FromSeconds(3),
                //    Action = () => this.Result("Toast Pressed")
                //})

                System.Threading.Tasks.Task.Run(() =>
                {

                    //if (engine == null)
                    //    engine = new DBreezeEngine(@"D:\temp\DBR1");

                    //using (var tran = engine.GetTransaction())
                    //{
                    //    tran.Insert<int, int>("t1", 1, 1);
                    //    tran.Commit();
                    //}
                });
        }
    }
}
