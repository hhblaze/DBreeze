﻿using System;

using Android.App;
using Android.Content.PM;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;

using DBreeze;
using DBreeze.Programmers;

namespace App1.Droid
{
    [Activity(Label = "App1", Icon = "@drawable/icon", Theme = "@style/MainTheme", MainLauncher = true, ConfigurationChanges = ConfigChanges.ScreenSize | ConfigChanges.Orientation)]
    public class MainActivity : global::Xamarin.Forms.Platform.Android.FormsAppCompatActivity
    {
        public static App PortableApp = null;

        protected override void OnCreate(Bundle bundle)
        {
            TabLayoutResource = Resource.Layout.Tabbar;
            ToolbarResource = Resource.Layout.Toolbar;

            base.OnCreate(bundle);

            global::Xamarin.Forms.Forms.Init(this, bundle);

            if (PortableApp == null)
            {
                PortableApp = new App();
                FSFactory fsf = new FSFactory();

                //Windows.Storage.StorageFolder localFolder = Windows.Storage.ApplicationData.Current.LocalFolder;
                var mfl = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal);

                PortableApp.engine = new DBreezeEngine(new DBreezeConfiguration()
                {
                    // DBreezeDataFolderName = "./sdcard/S-TEC/App1/V1",
                    DBreezeDataFolderName = mfl,
                    FSFactory = fsf
                });
            }

            LoadApplication(PortableApp);

          
        }
    }
}

